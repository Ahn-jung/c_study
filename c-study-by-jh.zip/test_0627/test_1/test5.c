#include <stdio.h>

void main(void)
{
    printf ("My name is Hong Gill Dong\r\n");
    printf ("I am 37 years old");
}