#include <stdio.h>

void main(void)
{
    printf("%s\r\n","My height");
    printf("%d\r\n",172);
    printf("%s\r\n","My weight");
    printf("%d",78);

}