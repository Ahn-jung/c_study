#include <stdio.h>

void main(void)
{
    printf("fun programming\r\n");
}