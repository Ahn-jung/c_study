#include <stdio.h>

void main(void)
{
    printf("수식을 출력하면 계산 결과가 출력됩니다.\r\n");
    printf("%d+%d=%d\r\n",10, 5, 10+5);
    printf("내 생년월일은 %d년 %d월 %d일 입니다.\r\n",2021-40,10,27);
    printf(" %d Dan \r\n",5);
    printf(" %d*%d=%d\r\n",5,2,5*2);

    printf("%8s\t%6s\r\n","Subject","score");
    printf("===================\r\n");
    printf("%8s\t%d\r\n",  "korea",90);
    printf("%8s\t%d\r\n",  "English",100);
    printf("%8s\t%d\r\n",  "computer",80);

    printf("%s","서식 문자를 이용한 print 실습\r\n");
    printf("\t%s","다음과 같은 출력을 서식 문자를 이용하여 출력하시오.\r\n");
    printf("\t\t%s","Test 7(각 요소들은 10의 공간을 확보\r\n");
    printf("\t\t%s\t%s\t%s\r\n","Item","Count","Price");
    printf("\t\t%s\t%d\t%d\r\n","Pen",20,100);
    printf("\t\t%s\t%d\t%d\r\n","Note",5,95);
    printf("\t\t%s\t%d\t%d","Note",110,97);
}
