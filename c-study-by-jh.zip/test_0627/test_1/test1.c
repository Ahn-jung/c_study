#include <stdio.h>

void main(void)
{
    printf("fun progra\r\n");
}