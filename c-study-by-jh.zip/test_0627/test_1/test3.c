#include <stdio.h>

void main(void)
{
    printf("두 번째 프로그램입니다."); printf("한 줄에 여러 문장을 출력합니다.");
}