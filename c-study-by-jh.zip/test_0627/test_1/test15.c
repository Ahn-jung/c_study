#include <stdio.h>

int main(void)
{
    int user_input=10000;//사람지급한금액
    int ietem_price=5300;//물건가격
    int change_money=user_input-ietem_price;
    
    printf("받을금액 : %d, 물건가격 %d : 거스름 돈: \r\n",
        user_input,ietem_price, change_money);
    printf("1000원의 개수 : \r\n",change_money/1000);
    printf("500원의 개수 : \r\n", (change_money%1000)/500);
    printf("100원의 개수 : \r\n", ((change_money%1000)%500)/100);
        return 0;
}