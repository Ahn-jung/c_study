#include <stdio.h>

void main(void)
{

    printf("%s로 출력하는 방법입니다.\r\n","서식문자");
    printf("%s은 문자열로 나타냅니다.\r\n","이것");
    printf("수를 출력할때 따옴표를 생략합니다.\r\n");
    printf("%d\r\n",123);
    printf("%f",6.5);

}