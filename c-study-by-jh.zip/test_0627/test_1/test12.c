#include <stdio.h>

int main(void)
{
int num1=10, num2=20; 
  
printf("%d +%d =%d\r\n",num1,num2,num1+num2);
return 0;
}