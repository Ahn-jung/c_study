#include <stdio.h>

void main(void)
{
    printf("세 번째 프로그램입니다.\r\n");
    printf("줄을 바꾸어 출력합니다.\r\n 여기까지 출력하고\r\n");
    printf("줄을 바꿉니다.");
}