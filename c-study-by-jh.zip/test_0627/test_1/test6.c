#include <stdio.h>

void main(void)
{

    printf("My name is %s","Hong Gill Dong\r\n");
    printf("I am %d years old\r\n",38);

    printf ("%3s\r\n","*");
    printf ("    ***\r\n");   
    printf ("   *****\r\n");
    printf ("    ***\r\n");
    printf ("     *");
}