#include <stdio.h>

int main(void)
{
    int result;
    int num1, num2;
    
     scanf("%d %d", &num1,&num2);

    result=num1+num2; 
    printf("%d", result);
    return 0;
} 