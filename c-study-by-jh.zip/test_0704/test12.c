#include <stdio.h>

int main(void)
{
    float num1, result;

    printf("yard? ",result);
    scanf("%f", &num1);

    result = num1*91.44;
    printf("%f =%0.1f",num1, result);
    return 0;
} 