#include <stdio.h>

int main(void)
{
    float result;
    float num1, num2;
    
     
     scanf("%d", &num1);

    result=num1; 
    printf("%d", result);
    return 0;
} 